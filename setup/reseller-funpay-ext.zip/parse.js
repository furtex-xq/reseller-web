/**
 * Разбор страницы заказов FunPay.
 *
 * Работает по настоящему DOM, а не по строкам: контент-скрипт живёт внутри
 * вкладки funpay.com, и querySelector тут надёжнее любого разбора руками.
 * Серверный разборщик (supabase/functions/funpay-sync/parse.ts) пришлось
 * писать вручную только потому, что в Deno не было DOM.
 *
 * Имена классов те же, что и там, и в web/src/funpay-export.user.js —
 * если FunPay переделает вёрстку, править придётся в трёх местах, зато
 * FIELD в каждом лежит первым же объектом.
 */
var RSParse = (function () {
  "use strict";

  var FIELD = {
    date: ["tc-date-time", "tc-date", "tc-time"],
    order: ["tc-order"],
    title: ["tc-desc-text", "tc-desc"],
    buyer: ["tc-user", "media-user-name", "tc-buyer"],
    status: ["tc-status"],
    price: ["tc-price", "tc-amount", "tc-sum"],
  };

  var ST = [
    [/оплач/i, "paid"],
    [/выдан|отправлен/i, "delivered"],
    [/закры|выполн|завершен/i, "closed"],
    [/возврат|отмен/i, "refunded"],
    [/спор|арбитраж/i, "dispute"],
    [/ожида|нов/i, "new"],
  ];

  function txt(el) {
    return el ? String(el.textContent || "").replace(/\s+/g, " ").trim() : "";
  }

  function pick(row, names) {
    for (var i = 0; i < names.length; i++) {
      var t = txt(row.querySelector("." + names[i]));
      if (t) return t;
    }
    return "";
  }

  function mapStatus(s) {
    for (var i = 0; i < ST.length; i++) if (ST[i][0].test(s)) return ST[i][1];
    return "new";
  }

  /** «1 250,50 ₽» -> { amount: 1250.5, currency: "RUB" } */
  function money(s) {
    var currency = /\$|usd/i.test(s) ? "USD" : /€|eur/i.test(s) ? "EUR" : "RUB";
    var n = String(s).replace(/[^\d.,-]/g, "");
    // Запятая — десятичный разделитель только если после неё 1-2 цифры.
    if (/,\d{1,2}$/.test(n)) n = n.replace(/\./g, "").replace(",", ".");
    else n = n.replace(/,/g, "");
    return { amount: parseFloat(n) || 0, currency: currency };
  }

  var MON = ["январ", "феврал", "март", "апрел", "ма", "июн",
             "июл", "август", "сентябр", "октябр", "ноябр", "декабр"];

  /**
   * «25 сентября, 14:07» / «сегодня, 14:07» -> ISO.
   *
   * Часовой пояс берём из самого браузера: страницу FunPay показывает по
   * московскому времени, и у вас в браузере оно же. На сервере приходилось
   * вычитать три часа вслепую — здесь этого не нужно.
   *
   * Не разобралось — пустая строка: честнее оставить дыру, которую заполнит
   * время синхронизации, чем подставить выдуманную дату.
   */
  function isoDate(s, now) {
    if (!s) return "";
    now = now || new Date();
    var hm = s.match(/(\d{1,2}):(\d{2})/);
    var h = hm ? +hm[1] : 0, mi = hm ? +hm[2] : 0;
    var d = null;

    if (/сегодня/i.test(s)) d = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    else if (/вчера/i.test(s)) d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
    else {
      var dm = s.match(/(\d{1,2})\s+([а-яё]+)/i);
      if (dm) {
        var low = dm[2].toLowerCase(), mon = -1;
        for (var i = 0; i < MON.length; i++) if (low.indexOf(MON[i]) === 0) { mon = i; break; }
        if (mon >= 0) {
          var yr = s.match(/\b(20\d{2})\b/);
          d = new Date(yr ? +yr[1] : now.getFullYear(), mon, +dm[1]);
          // Без года: дата из будущего — значит это прошлый год.
          if (!yr && d > now) d.setFullYear(d.getFullYear() - 1);
        }
      } else {
        var num = s.match(/(\d{2})[.\/](\d{2})[.\/](\d{2,4})/);
        if (num) d = new Date(+(num[3].length === 2 ? "20" + num[3] : num[3]), +num[2] - 1, +num[1]);
      }
    }
    if (!d || isNaN(d.getTime())) return "";
    d.setHours(h, mi, 0, 0);
    return d.toISOString().replace(/\.\d+Z$/, "Z");
  }

  /** Вошли ли мы на FunPay. userId лежит в data-app-data на <body>. */
  function userId(doc) {
    var el = (doc || document).querySelector("[data-app-data]");
    if (!el) return 0;
    try {
      return Number(JSON.parse(el.getAttribute("data-app-data")).userId || 0) || 0;
    } catch (e) {
      return 0;
    }
  }

  /** Заказы со страницы. doc — документ или любой его кусок. */
  function orders(doc, now) {
    var rows = (doc || document).querySelectorAll("a.tc-item, tr.tc-item, .tc-item");
    var out = [], seen = [];
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i];
      if (seen.indexOf(row) >= 0) continue;
      seen.push(row);

      var raw = [], cells = row.querySelectorAll("[class*='tc-']");
      for (var c = 0; c < cells.length; c++) {
        var t = txt(cells[c]);
        if (t && raw.indexOf(t) < 0) raw.push(t);
      }

      var num = pick(row, FIELD.order).replace(/^#/, "");
      if (!num) {
        var href = row.getAttribute("href") || "";
        var m = href.match(/([A-Z0-9]{6,})\/?$/i);
        if (m) num = m[1];
      }
      if (!num) continue;

      var p = money(pick(row, FIELD.price) || raw[raw.length - 1] || "");
      out.push({
        external_id: num,
        buyer_name: pick(row, FIELD.buyer),
        title_raw: pick(row, FIELD.title),
        status: mapStatus(pick(row, FIELD.status)),
        amount: p.amount,
        currency: p.currency,
        created_at: isoDate(pick(row, FIELD.date), now),
        _raw: raw,
      });
    }
    return out;
  }

  /* ────────────────────────────── отзывы ──────────────────────────────
     Разметка на странице продавца:

       <div class="review-container">
         <div class="review-item-rating"><div class="rating"><div class="rating5">
         <div class="review-item-date">9 месяцев назад</div>
         <div class="review-item-detail">PUBG Mobile, 100 ₽</div>
         <div class="review-item-text">текст покупателя</div>
         <div class="review-item-answer">ответ продавца</div>

     Точной даты в разметке нет — только «9 месяцев назад». Поэтому дата
     получается приблизительной, и так она и названа. Имени покупателя в
     публичном виде тоже нет; если в своём кабинете FunPay его показывает,
     разбор подхватит, а нет — оставит пустым. */

  var ЕДИНИЦЫ = [
    [/секунд/i, 1000],
    [/минут/i, 60 * 1000],
    [/час/i, 3600 * 1000],
    [/(день|дня|дней|сутк)/i, 86400 * 1000],
    [/недел/i, 7 * 86400 * 1000],
    [/месяц/i, 30 * 86400 * 1000],
    [/(год|года|лет)/i, 365 * 86400 * 1000],
  ];

  /** «9 месяцев назад» -> примерная дата. Не разобралось — пустая строка. */
  function давность(текст, сейчас) {
    var s = String(текст || "").trim();
    if (!s) return "";
    сейчас = сейчас ? сейчас.getTime() : Date.now();
    if (/сегодня|только что/i.test(s)) return new Date(сейчас).toISOString();
    if (/вчера/i.test(s)) return new Date(сейчас - 86400000).toISOString();

    var м = s.match(/([0-9]+)/);
    // «месяц назад» без числа — значит один.
    var n = м ? parseInt(м[1], 10) : 1;
    for (var i = 0; i < ЕДИНИЦЫ.length; i++) {
      if (ЕДИНИЦЫ[i][0].test(s)) return new Date(сейчас - n * ЕДИНИЦЫ[i][1]).toISOString();
    }
    return "";
  }

  /** Оценка: класс ratingN внутри блока. */
  function оценка(узел) {
    var все = узел.querySelectorAll("[class]");
    for (var i = 0; i < все.length; i++) {
      var m = String(все[i].className).match(/(?:^|[ ])rating([1-5])(?:[ ]|$)/);
      if (m) return Number(m[1]);
    }
    return 0;
  }

  /** «PUBG Mobile, 100 ₽» -> { game, amount, currency } */
  function деталь(текст) {
    var s = String(текст || "").trim();
    var i = s.lastIndexOf(",");
    if (i < 0) return { game: s, amount: 0, currency: "RUB" };
    var деньги = money(s.slice(i + 1));
    return { game: s.slice(0, i).trim(), amount: деньги.amount, currency: деньги.currency };
  }

  /** Отпечаток вместо номера: своего id у отзыва на FunPay нет. */
  function отпечаток(о) {
    var s = о.rating + "|" + (о.detail || "") + "|" + String(о.body || "").slice(0, 160);
    var h = 5381;
    for (var i = 0; i < s.length; i++) h = ((h * 33) ^ s.charCodeAt(i)) >>> 0;
    return h.toString(36) + "-" + s.length.toString(36);
  }

  function отзывы(doc, сейчас) {
    var блоки = (doc || document).querySelectorAll(".review-container, .review-item");
    var out = [], видели = [];
    for (var i = 0; i < блоки.length; i++) {
      var b = блоки[i];
      // .review-item лежит внутри .review-container — не считаем дважды.
      if (видели.some(function (p) { return p.contains(b); })) continue;
      видели.push(b);

      var текст = txt(b.querySelector(".review-item-text"));
      var d = txt(b.querySelector(".review-item-detail"));
      var о = {
        rating: оценка(b),
        body: текст,
        reply: txt(b.querySelector(".review-item-answer")),
        detail: d,
        author: txt(b.querySelector(".media-user-name, .review-item-user a")),
        approx_at: давность(txt(b.querySelector(".review-item-date")), сейчас),
      };
      var раз = деталь(d);
      о.game = раз.game; о.amount = раз.amount; о.currency = раз.currency;

      // Номер заказа встречается только в своём кабинете, и то не всегда.
      var ссылка = b.querySelector("a[href*=\"/orders/\"]");
      о.external_id = ссылка ? (String(ссылка.getAttribute("href")).match(/([A-Z0-9]{6,})/i) || [])[1] || "" : "";

      if (!о.rating) continue;            // без оценки это не отзыв
      о.fingerprint = отпечаток(о);
      out.push(о);
    }
    return out;
  }

  /** Сводка для значка и отладки: сколько полей реально разобралось. */
  function quality(list) {
    var q = { всего: list.length, сНомером: 0, сПокупателем: 0, сДатой: 0, сСуммой: 0 };
    list.forEach(function (o) {
      if (o.external_id) q.сНомером++;
      if (o.buyer_name) q.сПокупателем++;
      if (o.created_at) q.сДатой++;
      if (o.amount > 0) q.сСуммой++;
    });
    return q;
  }

  return {
    FIELD: FIELD,
    orders: orders,
    userId: userId,
    quality: quality,
    отзывы: отзывы,
    давность: давность,
    деталь: деталь,
    money: money,
    isoDate: isoDate,
    mapStatus: mapStatus,
  };
})();

if (typeof module !== "undefined" && module.exports) module.exports = RSParse;
