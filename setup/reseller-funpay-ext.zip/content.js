/**
 * Живёт во вкладке funpay.com и читает заказы.
 *
 * Почему именно здесь, а не в фоновом скрипте: у FunPay cookie с политикой
 * Lax, а запрос из фонового скрипта расширения считается сторонним, и такие
 * cookie в него не попадают. Для контент-скрипта запрос к /orders/trade —
 * свой собственный, и сессия уходит гарантированно. Это и есть вся причина,
 * по которой затея с сервером провалилась, а расширение работает.
 *
 * Скрипт только читает. Ничего не нажимает, не отвечает покупателям, не
 * трогает лоты и не знает пароля.
 */
(function () {
  "use strict";

  var ORDERS = "/orders/trade";
  var МИН = 60 * 1000;
  var таймер = null;
  var идёт = false;

  function сообщить(payload) {
    try {
      chrome.runtime.sendMessage(payload, function () {
        // Фоновый скрипт мог уснуть — ответ нас не интересует, но без
        // обработчика Chrome пишет в консоль «unchecked runtime.lastError».
        void chrome.runtime.lastError;
      });
    } catch (e) { /* расширение перезагрузили — переживём до следующего раза */ }
  }

  /** Страница заказов: своя, если мы уже на ней, иначе тянем отдельно. */
  function взятьСтраницу() {
    if (location.pathname.indexOf(ORDERS) === 0) return Promise.resolve(document);
    return fetch(ORDERS, { credentials: "same-origin", headers: { "accept": "text/html" } })
      .then(function (r) {
        if (!r.ok) throw new Error("FunPay ответил " + r.status);
        return r.text();
      })
      .then(function (html) {
        return new DOMParser().parseFromString(html, "text/html");
      });
  }

  /* ─────────────────────── листание в глубину ───────────────────────
     FunPay листает все свои таблицы одинаково: рядом с кнопкой «Показать
     ещё» лежит форма с токеном продолжения, её и отправляют POST-ом.

       <form class="dyn-table-form" action="…">
         <input type="hidden" name="continue" value="Z+hrxwrr3pE=">
       </form>

     Ответ приходит либо JSON-ом с полем html, либо куском разметки — берём
     оба случая, потому что на разных страницах у них по-разному. */

  /** Форма продолжения: из документа или из полученного куска. */
  function формаПродолжения(корень) {
    var f = корень.querySelector("form.dyn-table-form");
    if (!f) return null;
    var поля = {};
    var есть = false;
    f.querySelectorAll("input[name]").forEach(function (i) {
      поля[i.name] = i.value;
      if (i.name === "continue" && i.value) есть = true;
    });
    if (!есть) return null;
    return { адрес: f.getAttribute("action") || location.href, поля: поля };
  }

  /** Ответ FunPay: разметка как есть либо внутри JSON. */
  function разметкаОтвета(текст) {
    var t = String(текст).trim();
    if (t.charAt(0) === "{") {
      try {
        var j = JSON.parse(t);
        return { html: j.html || "", дальше: j["continue"] || "" };
      } catch (e) { /* не JSON — ниже как разметка */ }
    }
    return { html: t, дальше: "" };
  }

  /**
   * Дочитать таблицу до конца.
   *
   * `страниц` — сколько ещё кусков тянуть. При обычной сверке ноль: свежие
   * заказы и так на первой странице, а гонять всю историю каждые пять минут
   * незачем. Глубокий проход запускается отдельно и один раз.
   */
  function дочитать(doc, страниц, оПрогрессе) {
    var собрано = RSParse.orders(doc);
    var форма = формаПродолжения(doc);
    var виденные = {};                 // токены, чтобы не ходить по кругу
    var страница = 1;

    function шаг() {
      if (!форма || страниц <= 0) return Promise.resolve(собрано);
      var токен = форма.поля["continue"];
      if (!токен || виденные[токен]) return Promise.resolve(собрано);
      виденные[токен] = true;
      страниц--;

      var тело = new URLSearchParams();
      for (var k in форма.поля) тело.append(k, форма.поля[k]);

      return fetch(форма.адрес, {
        method: "POST",
        credentials: "same-origin",
        headers: {
          "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
          "x-requested-with": "XMLHttpRequest",
        },
        body: тело.toString(),
      }).then(function (r) {
        if (!r.ok) throw new Error("FunPay ответил " + r.status + " на листание");
        return r.text();
      }).then(function (текст) {
        var ответ = разметкаОтвета(текст);
        if (!ответ.html) return собрано;

        var кусок = new DOMParser().parseFromString(
          "<html><body>" + ответ.html + "</body></html>", "text/html");
        var новые = RSParse.orders(кусок);

        // Страница без единого заказа — значит дочитали до конца.
        var было = собрано.length;
        var номера = {};
        собрано.forEach(function (o) { номера[o.external_id] = true; });
        новые.forEach(function (o) { if (!номера[o.external_id]) собрано.push(o); });
        if (собрано.length === было) return собрано;

        страница++;
        if (оПрогрессе) оПрогрессе(страница, собрано.length);

        // Следующий токен: из JSON либо из формы в присланном куске.
        var следующая = формаПродолжения(кусок);
        if (следующая) форма = следующая;
        else if (ответ.дальше) форма = { адрес: форма.адрес, поля: Object.assign({}, форма.поля, { "continue": ответ.дальше }) };
        else форма = null;

        return шаг();
      });
    }

    return шаг();
  }

  function синхронизировать(повод, страниц) {
    if (идёт) return;
    идёт = true;
    var глубоко = (страниц || 0) > 0;
    return взятьСтраницу().then(function (doc) {
      var uid = RSParse.userId(doc);
      if (!uid) {
        // Вышли из аккаунта или сессия истекла — молча копить пустоту нельзя.
        сообщить({ тип: "нетВхода", повод: повод });
        return;
      }
      return дочитать(doc, страниц || 0, глубоко ? function (стр, всего) {
        // Глубокий проход идёт минутами — показываем, что не завис.
        сообщить({ тип: "прогресс", страница: стр, заказов: всего });
      } : null).then(function (список) {
        отправить(повод, uid, список, глубоко);
      });
    }).catch(function (e) {
      сообщить({ тип: "ошибка", повод: повод, текст: String(e && e.message || e) });
    }).then(function () {
      идёт = false;
    });
  }

  function отправить(повод, uid, список, глубоко) {
    сообщить({
      тип: "заказы",
      повод: повод,
      userId: uid,
      глубоко: !!глубоко,
      заказы: список.map(function (o) {
        // _raw нужен только когда что-то не разобралось: гонять его всегда
        // через messaging незачем.
        var copy = Object.assign({}, o);
        delete copy._raw;
        return copy;
      }),
      качество: RSParse.quality(список),
      сырые: список.filter(function (o) { return !o.buyer_name || !o.created_at; })
        .slice(0, 3).map(function (o) { return o._raw; }),
    });
  }

  /** Расписание задаётся в настройках; 0 выключает автоматику. */
  function завести(минут) {
    if (таймер) clearInterval(таймер);
    таймер = null;
    if (годенИнтервал(минут)) таймер = setInterval(function () { синхронизировать("по расписанию"); }, минут * МИН);
  }
  function годенИнтервал(m) { return typeof m === "number" && m >= 1; }

  chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
    if (msg && msg.тип === "синхронизируй") {
      // Глубина приходит только для разового прохода по всей истории.
      синхронизировать(msg.повод || "по запросу", msg.страниц || 0);
      sendResponse({ принято: true });
    }
    if (msg && msg.тип === "расписание") завести(msg.минут);
    return true;
  });

  // Первый заход — сразу: человек открыл FunPay, значит данные свежие.
  chrome.storage.local.get({ интервал: 5 }, function (s) {
    завести(s.интервал);
    синхронизировать("открыта вкладка");
  });
})();
