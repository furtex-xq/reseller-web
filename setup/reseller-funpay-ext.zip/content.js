/**
 * Живёт во вкладке funpay.com и читает заказы.
 *
 * Почему именно здесь, а не в фоновом скрипте: у FunPay cookie с политикой
 * Lax, а запрос из фонового скрипта расширения считается сторонним, и такие
 * cookie в него не попадают. Для контент-скрипта запрос к /orders/trade —
 * свой собственный, и сессия уходит гарантированно. Это и есть вся причина,
 * по которой затея с сервером провалилась, а расширение работает.
 *
 * Скрипт только читает. Ничего не нажимает, не отвечает покупателям, не
 * трогает лоты и не знает пароля.
 */
(function () {
  "use strict";

  var ORDERS = "/orders/trade";
  var МИН = 60 * 1000;
  var таймер = null;
  var идёт = false;

  function сообщить(payload) {
    try {
      chrome.runtime.sendMessage(payload, function () {
        // Фоновый скрипт мог уснуть — ответ нас не интересует, но без
        // обработчика Chrome пишет в консоль «unchecked runtime.lastError».
        void chrome.runtime.lastError;
      });
    } catch (e) { /* расширение перезагрузили — переживём до следующего раза */ }
  }

  /** Страница заказов: своя, если мы уже на ней, иначе тянем отдельно. */
  function взятьСтраницу() {
    if (location.pathname.indexOf(ORDERS) === 0) return Promise.resolve(document);
    return fetch(ORDERS, { credentials: "same-origin", headers: { "accept": "text/html" } })
      .then(function (r) {
        if (!r.ok) throw new Error("FunPay ответил " + r.status);
        return r.text();
      })
      .then(function (html) {
        return new DOMParser().parseFromString(html, "text/html");
      });
  }

  function синхронизировать(повод) {
    if (идёт) return;
    идёт = true;
    return взятьСтраницу().then(function (doc) {
      var uid = RSParse.userId(doc);
      if (!uid) {
        // Вышли из аккаунта или сессия истекла — молча копить пустоту нельзя.
        сообщить({ тип: "нетВхода", повод: повод });
        return;
      }
      var список = RSParse.orders(doc);
      сообщить({
        тип: "заказы",
        повод: повод,
        userId: uid,
        заказы: список.map(function (o) {
          // _raw нужен только когда что-то не разобралось: гонять его всегда
          // через messaging незачем.
          var copy = Object.assign({}, o);
          delete copy._raw;
          return copy;
        }),
        качество: RSParse.quality(список),
        сырые: список.filter(function (o) { return !o.buyer_name || !o.created_at; })
          .slice(0, 3).map(function (o) { return o._raw; }),
      });
    }).catch(function (e) {
      сообщить({ тип: "ошибка", повод: повод, текст: String(e && e.message || e) });
    }).then(function () {
      идёт = false;
    });
  }

  /** Расписание задаётся в настройках; 0 выключает автоматику. */
  function завести(минут) {
    if (таймер) clearInterval(таймер);
    таймер = null;
    if (годенИнтервал(минут)) таймер = setInterval(function () { синхронизировать("по расписанию"); }, минут * МИН);
  }
  function годенИнтервал(m) { return typeof m === "number" && m >= 1; }

  chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
    if (msg && msg.тип === "синхронизируй") {
      синхронизировать(msg.повод || "по запросу");
      sendResponse({ принято: true });
    }
    if (msg && msg.тип === "расписание") завести(msg.минут);
    return true;
  });

  // Первый заход — сразу: человек открыл FunPay, значит данные свежие.
  chrome.storage.local.get({ интервал: 5 }, function (s) {
    завести(s.интервал);
    синхронизировать("открыта вкладка");
  });
})();
