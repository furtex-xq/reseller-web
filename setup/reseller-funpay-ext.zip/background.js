/**
 * Фоновый скрипт: принимает заказы от вкладки FunPay и кладёт их в Supabase.
 *
 * Сам на FunPay не ходит и ходить не может — cookie с политикой Lax сюда не
 * передаются. Его дело: вход в Supabase, запись, расписание и значок.
 *
 * В Supabase ходим публичным ключом плюс токеном вошедшего: секретные ключи
 * Supabase запрещает держать вне сервера, и расширение — не исключение.
 */

const ПО_УМОЛЧАНИЮ = { url: "", anon: "", интервал: 5, email: "" };

/* ---------------- хранилище ---------------- */

function взять(ключи) {
  return new Promise((r) => chrome.storage.local.get(ключи, r));
}
function положить(о) {
  return new Promise((r) => chrome.storage.local.set(о, r));
}

/* ---------------- вход ----------------
   Пароль не храним: после входа остаются только токены. Токен живёт около
   часа, поэтому рядом лежит refresh_token, по которому берётся следующий. */

async function токен() {
  const s = await взять({ url: "", anon: "", token: "", refresh: "", at: 0 });
  if (!s.url || !s.anon) throw new Error("не настроено: нет адреса проекта или публичного ключа");
  // Минута запаса: иначе токен успеет протухнуть между проверкой и запросом.
  if (s.token && Date.now() < s.at - 60000) return s;
  if (!s.refresh) throw new Error("нужно войти в настройках расширения");

  const r = await fetch(s.url + "/auth/v1/token?grant_type=refresh_token", {
    method: "POST",
    headers: { apikey: s.anon, "Content-Type": "application/json" },
    body: JSON.stringify({ refresh_token: s.refresh }),
  });
  const j = await r.json();
  if (!r.ok) {
    await положить({ token: "", refresh: "", at: 0 });
    throw new Error("вход просрочен — войдите заново в настройках");
  }
  const свежее = {
    token: j.access_token || "",
    refresh: j.refresh_token || s.refresh,
    at: Date.now() + (Number(j.expires_in) || 3600) * 1000,
  };
  await положить(свежее);
  return Object.assign({}, s, свежее);
}

async function rest(s, path, init = {}) {
  const r = await fetch(s.url + "/rest/v1/" + path, {
    ...init,
    headers: {
      apikey: s.anon,
      Authorization: "Bearer " + s.token,
      "Content-Type": "application/json",
      ...(init.headers || {}),
    },
  });
  if (!r.ok) {
    const body = (await r.text()).slice(0, 200);
    if (r.status === 401) throw new Error("Supabase не пустил: войдите заново");
    if (r.status === 404) throw new Error("в базе нет таблиц — выполните SQL из мастера");
    throw new Error("Supabase " + r.status + ": " + body);
  }
  return r;
}

/**
 * К какому аккаунту привязывать заказы.
 *
 * Ищем существующий и только потом создаём: у orders ключ
 * (account_id, external_id), и на двух аккаунтах один заказ FunPay ляжет
 * двумя строками.
 */
/**
 * К какому аккаунту привязывать заказы.
 *
 * Тонкое место. У заказов ключ (account_id, external_id), то есть один и тот
 * же заказ FunPay под двумя аккаунтами ляжет двумя строками. А аккаунтов в
 * базе легко становится два: свой заводит телефон при выгрузке, свой —
 * расширение. Сойтись они должны на одном.
 *
 * Общий признак у них один — номер продавца на FunPay: расширение читает его
 * со страницы, и он не меняется. По нему и ищем, а найдя аккаунт без номера,
 * проставляем — чтобы в следующий раз совпадение было точным.
 */
async function аккаунт(s, userId) {
  const метка = userId ? String(userId) : "";
  const все = await (await rest(s, "accounts?platform=eq.funpay&select=id,label,external_id")).json();

  // 1. Точное совпадение по номеру продавца.
  const свой = метка && все.find((a) => String(a.external_id || "") === метка);
  if (свой) {
    await положить({ accountId: свой.id });
    return свой.id;
  }

  // 2. Тот, которым пользовались раньше. Заодно проставим ему номер.
  const было = await взять({ accountId: "" });
  const прежний = было.accountId && все.find((a) => a.id === было.accountId);
  if (прежний) {
    if (метка && !прежний.external_id) await пометить(s, прежний.id, метка);
    return прежний.id;
  }

  // 3. Единственный funpay-аккаунт — очевидно он.
  if (все.length === 1) {
    if (метка && !все[0].external_id) await пометить(s, все[0].id, метка);
    await положить({ accountId: все[0].id });
    return все[0].id;
  }

  // 4. Несколько, и ни один не подписан номером. Угадывать нельзя: ошибка
  //    тихо раздвоит все заказы, и разбирать их потом придётся руками.
  if (все.length > 1) {
    throw new Error(
      "в базе несколько аккаунтов FunPay (" + все.map((a) => a.label).join(", ") +
      ") и ни один не подписан номером продавца. Оставьте один в панели.",
    );
  }

  // 5. Пусто — заводим.
  const создан = await (await rest(s, "accounts?on_conflict=platform,label&select=id", {
    method: "POST",
    headers: { Prefer: "resolution=merge-duplicates,return=representation" },
    body: JSON.stringify([{
      platform: "funpay", label: "Основной", external_id: метка || null,
      session_key: "chrome-ext", is_active: true,
    }]),
  })).json();
  await положить({ accountId: создан[0].id });
  return создан[0].id;
}

/** Подписать аккаунт номером продавца, чтобы телефон и расширение сошлись. */
async function пометить(s, id, метка) {
  try {
    await rest(s, "accounts?id=eq." + encodeURIComponent(id), {
      method: "PATCH",
      headers: { Prefer: "return=minimal" },
      body: JSON.stringify({ external_id: метка }),
    });
  } catch (e) { /* не вышло — не беда, в следующий раз попробуем снова */ }
}

/* ---------------- запись заказов ---------------- */

async function записать(заказы, userId) {
  if (!заказы.length) return { записано: 0 };
  const s = await токен();
  const accId = await аккаунт(s, userId);
  const сейчас = new Date().toISOString();

  const строки = заказы.map((o) => ({
    account_id: accId,
    platform: "funpay",
    external_id: o.external_id,
    buyer_name: o.buyer_name || null,
    title_raw: o.title_raw || null,
    amount: o.amount,
    currency: o.currency,
    status: o.status,
    ...(o.status === "delivered" ? { delivered_at: o.created_at || сейчас } : {}),
    ...(o.status === "closed" ? { closed_at: o.created_at || сейчас } : {}),
    created_at: o.created_at || сейчас,
  }));

  /* PostgREST принимает пачку, только если у всех записей совпадает набор
     полей, иначе отвечает PGRST102 «All object keys must match». А записи
     различаются: у выданного заказа есть delivered_at, у закрытого —
     closed_at. Поэтому группируем по набору ключей.

     Почему не подставить null вместо отсутствующих: upsert перезаписывает
     всё, что прислали, и null затёр бы уже проставленную дату выдачи, когда
     заказ перешёл из «выдан» в «закрыт». Пропущенный ключ колонку не трогает. */
  const группы = new Map();
  for (const строка of строки) {
    const ключ = Object.keys(строка).sort().join(",");
    if (!группы.has(ключ)) группы.set(ключ, []);
    группы.get(ключ).push(строка);
  }

  // Пишем пачками: одна простыня на несколько сотен заказов упирается в
  // ограничения на размер запроса, а порция по сотне проходит всегда.
  const ПАЧКА = 100;
  for (const группа of группы.values()) {
    for (let i = 0; i < группа.length; i += ПАЧКА) {
      await rest(s, "orders?on_conflict=account_id,external_id", {
        method: "POST",
        headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
        body: JSON.stringify(группа.slice(i, i + ПАЧКА)),
      });
    }
  }
  return { записано: строки.length, пачек: группы.size };
}

/* ---------------- значок ---------------- */

async function значок(текст, цвет, подсказка) {
  try {
    await chrome.action.setBadgeText({ text: текст });
    await chrome.action.setBadgeBackgroundColor({ color: цвет });
    if (подсказка) await chrome.action.setTitle({ title: подсказка });
  } catch (e) { /* значка может не быть — не повод падать */ }
}

async function состояние(о) {
  // Версия в каждой записи: без неё «не починилось» не отличить от
  // «Chrome крутит старый фоновый скрипт», а это разные беды.
  await положить({
    состояние: Object.assign(
      { когда: new Date().toISOString(), версия: chrome.runtime.getManifest().version },
      о,
    ),
  });
}

/* ---------------- разбор сообщений от вкладки ---------------- */

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    try {
      if (msg.тип === "прогресс") {
        // Глубокий проход идёт минутами: показываем на значке, что живой.
        await значок(String(msg.заказов), "#58a6ff",
          "Читаю историю: страница " + msg.страница + ", заказов " + msg.заказов);
        await состояние({ ok: true, идёт: true, записано: 0, качество: { всего: msg.заказов } });
        return sendResponse({ ok: true });
      }

      if (msg.тип === "нетВхода") {
        await значок("!", "#d29922", "Вы не вошли на FunPay");
        await состояние({ ok: false, причина: "на FunPay нет входа" });
        return sendResponse({ ok: false });
      }

      if (msg.тип === "ошибка") {
        await значок("!", "#f85149", "Ошибка: " + msg.текст);
        await состояние({ ok: false, причина: msg.текст });
        return sendResponse({ ok: false });
      }

      if (msg.тип === "заказы") {
        const итог = await записать(msg.заказы, msg.userId);
        const q = msg.качество || {};
        const плохо = (q.всего || 0) - Math.min(q.сПокупателем || 0, q.сДатой || 0);
        await значок(
          String(итог.записано),
          плохо ? "#d29922" : "#2dd4bf",
          "Заказов: " + итог.записано + (плохо ? ", не разобралось: " + плохо : "") +
          "\nПоследняя сверка: " + new Date().toLocaleTimeString("ru-RU"),
        );
        await состояние({
          ok: true, записано: итог.записано, качество: q,
          сырые: плохо ? msg.сырые : null, userId: msg.userId,
        });
        return sendResponse({ ok: true, записано: итог.записано });
      }

      if (msg.тип === "подтолкни") {
        await подтолкнуть("из панели", msg.страниц || 0);
        return sendResponse({ ok: true });
      }

      if (msg.тип === "настройкиИзменились") {
        await разослатьРасписание();
        return sendResponse({ ok: true });
      }
    } catch (e) {
      const текст = String((e && e.message) || e);
      await значок("!", "#f85149", "Ошибка: " + текст);
      await состояние({ ok: false, причина: текст });
      sendResponse({ ok: false, причина: текст });
    }
  })();
  return true;                       // ответ придёт асинхронно
});

/* ---------------- расписание ---------------- */

async function вкладкиFunPay() {
  return await chrome.tabs.query({ url: "https://funpay.com/*" });
}

async function разослатьРасписание() {
  const { интервал } = await взять({ интервал: ПО_УМОЛЧАНИЮ.интервал });
  for (const t of await вкладкиFunPay()) {
    try { await chrome.tabs.sendMessage(t.id, { тип: "расписание", минут: интервал }); }
    catch (e) { /* вкладка ещё не подхватила скрипт */ }
  }
}

async function подтолкнуть(повод, страниц) {
  const вкладки = await вкладкиFunPay();
  if (!вкладки.length) {
    await значок("—", "#8b949e", "Нет открытых вкладок FunPay — синхронизация ждёт");
    return;
  }
  for (const t of вкладки) {
    try { await chrome.tabs.sendMessage(t.id, { тип: "синхронизируй", повод: повод, страниц: страниц || 0 }); }
    catch (e) { /* вкладка не готова, попробуем в следующий раз */ }
  }
}

chrome.alarms.create("сверка", { periodInMinutes: 5 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "сверка") подтолкнуть("будильник");
});

chrome.runtime.onInstalled.addListener(async () => {
  const s = await взять(ПО_УМОЛЧАНИЮ);
  if (!s.url || !s.anon) {
    await значок("?", "#d29922", "Откройте настройки расширения");
    chrome.runtime.openOptionsPage();
  }
});
