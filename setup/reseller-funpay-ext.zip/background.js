/**
 * Фоновый скрипт: принимает заказы от вкладки FunPay и кладёт их в Supabase.
 *
 * Сам на FunPay не ходит и ходить не может — cookie с политикой Lax сюда не
 * передаются. Его дело: вход в Supabase, запись, расписание и значок.
 *
 * В Supabase ходим публичным ключом плюс токеном вошедшего: секретные ключи
 * Supabase запрещает держать вне сервера, и расширение — не исключение.
 */

const ПО_УМОЛЧАНИЮ = { url: "", anon: "", интервал: 5, email: "" };

/* ---------------- хранилище ---------------- */

function взять(ключи) {
  return new Promise((r) => chrome.storage.local.get(ключи, r));
}
function положить(о) {
  return new Promise((r) => chrome.storage.local.set(о, r));
}

/* ---------------- вход ----------------
   Пароль не храним: после входа остаются только токены. Токен живёт около
   часа, поэтому рядом лежит refresh_token, по которому берётся следующий. */

async function токен() {
  const s = await взять({ url: "", anon: "", token: "", refresh: "", at: 0 });
  if (!s.url || !s.anon) throw new Error("не настроено: нет адреса проекта или публичного ключа");
  // Минута запаса: иначе токен успеет протухнуть между проверкой и запросом.
  if (s.token && Date.now() < s.at - 60000) return s;
  if (!s.refresh) throw new Error("нужно войти в настройках расширения");

  const r = await fetch(s.url + "/auth/v1/token?grant_type=refresh_token", {
    method: "POST",
    headers: { apikey: s.anon, "Content-Type": "application/json" },
    body: JSON.stringify({ refresh_token: s.refresh }),
  });
  const j = await r.json();
  if (!r.ok) {
    await положить({ token: "", refresh: "", at: 0 });
    throw new Error("вход просрочен — войдите заново в настройках");
  }
  const свежее = {
    token: j.access_token || "",
    refresh: j.refresh_token || s.refresh,
    at: Date.now() + (Number(j.expires_in) || 3600) * 1000,
  };
  await положить(свежее);
  return Object.assign({}, s, свежее);
}

async function rest(s, path, init = {}) {
  const r = await fetch(s.url + "/rest/v1/" + path, {
    ...init,
    headers: {
      apikey: s.anon,
      Authorization: "Bearer " + s.token,
      "Content-Type": "application/json",
      ...(init.headers || {}),
    },
  });
  if (!r.ok) {
    const body = (await r.text()).slice(0, 200);
    if (r.status === 401) throw new Error("Supabase не пустил: войдите заново");
    if (r.status === 404) throw new Error("в базе нет таблиц — выполните SQL из мастера");
    throw new Error("Supabase " + r.status + ": " + body);
  }
  return r;
}

/**
 * К какому аккаунту привязывать заказы.
 *
 * Ищем существующий и только потом создаём: у orders ключ
 * (account_id, external_id), и на двух аккаунтах один заказ FunPay ляжет
 * двумя строками.
 */
async function аккаунт(s) {
  const было = await взять({ accountId: "" });
  if (было.accountId) return было.accountId;

  const есть = await (await rest(s, "accounts?platform=eq.funpay&select=id,label")).json();
  if (есть.length === 1) {
    await положить({ accountId: есть[0].id });
    return есть[0].id;
  }
  if (есть.length > 1) {
    throw new Error("в базе несколько funpay-аккаунтов — оставьте один или выберите в панели");
  }
  const создан = await (await rest(s, "accounts?on_conflict=platform,label&select=id", {
    method: "POST",
    headers: { Prefer: "resolution=merge-duplicates,return=representation" },
    body: JSON.stringify([{
      platform: "funpay", label: "Основной",
      session_key: "chrome-ext", is_active: true,
    }]),
  })).json();
  await положить({ accountId: создан[0].id });
  return создан[0].id;
}

/* ---------------- запись заказов ---------------- */

async function записать(заказы) {
  if (!заказы.length) return { записано: 0 };
  const s = await токен();
  const accId = await аккаунт(s);
  const сейчас = new Date().toISOString();

  const строки = заказы.map((o) => ({
    account_id: accId,
    platform: "funpay",
    external_id: o.external_id,
    buyer_name: o.buyer_name || null,
    title_raw: o.title_raw || null,
    amount: o.amount,
    currency: o.currency,
    status: o.status,
    ...(o.status === "delivered" ? { delivered_at: o.created_at || сейчас } : {}),
    ...(o.status === "closed" ? { closed_at: o.created_at || сейчас } : {}),
    created_at: o.created_at || сейчас,
  }));

  // Пишем пачками: одна простыня на несколько сотен заказов упирается в
  // ограничения на размер запроса, а порция по сотне проходит всегда.
  const ПАЧКА = 100;
  for (let i = 0; i < строки.length; i += ПАЧКА) {
    await rest(s, "orders?on_conflict=account_id,external_id", {
      method: "POST",
      headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
      body: JSON.stringify(строки.slice(i, i + ПАЧКА)),
    });
  }
  return { записано: строки.length };
}

/* ---------------- значок ---------------- */

async function значок(текст, цвет, подсказка) {
  try {
    await chrome.action.setBadgeText({ text: текст });
    await chrome.action.setBadgeBackgroundColor({ color: цвет });
    if (подсказка) await chrome.action.setTitle({ title: подсказка });
  } catch (e) { /* значка может не быть — не повод падать */ }
}

async function состояние(о) {
  await положить({ состояние: Object.assign({ когда: new Date().toISOString() }, о) });
}

/* ---------------- разбор сообщений от вкладки ---------------- */

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    try {
      if (msg.тип === "нетВхода") {
        await значок("!", "#d29922", "Вы не вошли на FunPay");
        await состояние({ ok: false, причина: "на FunPay нет входа" });
        return sendResponse({ ok: false });
      }

      if (msg.тип === "ошибка") {
        await значок("!", "#f85149", "Ошибка: " + msg.текст);
        await состояние({ ok: false, причина: msg.текст });
        return sendResponse({ ok: false });
      }

      if (msg.тип === "заказы") {
        const итог = await записать(msg.заказы);
        const q = msg.качество || {};
        const плохо = (q.всего || 0) - Math.min(q.сПокупателем || 0, q.сДатой || 0);
        await значок(
          String(итог.записано),
          плохо ? "#d29922" : "#2dd4bf",
          "Заказов: " + итог.записано + (плохо ? ", не разобралось: " + плохо : "") +
          "\nПоследняя сверка: " + new Date().toLocaleTimeString("ru-RU"),
        );
        await состояние({
          ok: true, записано: итог.записано, качество: q,
          сырые: плохо ? msg.сырые : null, userId: msg.userId,
        });
        return sendResponse({ ok: true, записано: итог.записано });
      }

      if (msg.тип === "настройкиИзменились") {
        await разослатьРасписание();
        return sendResponse({ ok: true });
      }
    } catch (e) {
      const текст = String((e && e.message) || e);
      await значок("!", "#f85149", "Ошибка: " + текст);
      await состояние({ ok: false, причина: текст });
      sendResponse({ ok: false, причина: текст });
    }
  })();
  return true;                       // ответ придёт асинхронно
});

/* ---------------- расписание ---------------- */

async function вкладкиFunPay() {
  return await chrome.tabs.query({ url: "https://funpay.com/*" });
}

async function разослатьРасписание() {
  const { интервал } = await взять({ интервал: ПО_УМОЛЧАНИЮ.интервал });
  for (const t of await вкладкиFunPay()) {
    try { await chrome.tabs.sendMessage(t.id, { тип: "расписание", минут: интервал }); }
    catch (e) { /* вкладка ещё не подхватила скрипт */ }
  }
}

async function подтолкнуть(повод) {
  const вкладки = await вкладкиFunPay();
  if (!вкладки.length) {
    await значок("—", "#8b949e", "Нет открытых вкладок FunPay — синхронизация ждёт");
    return;
  }
  for (const t of вкладки) {
    try { await chrome.tabs.sendMessage(t.id, { тип: "синхронизируй", повод: повод }); }
    catch (e) { /* вкладка не готова, попробуем в следующий раз */ }
  }
}

chrome.alarms.create("сверка", { periodInMinutes: 5 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "сверка") подтолкнуть("будильник");
});

chrome.runtime.onInstalled.addListener(async () => {
  const s = await взять(ПО_УМОЛЧАНИЮ);
  if (!s.url || !s.anon) {
    await значок("?", "#d29922", "Откройте настройки расширения");
    chrome.runtime.openOptionsPage();
  }
});
