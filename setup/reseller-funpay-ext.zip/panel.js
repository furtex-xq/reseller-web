/**
 * Мост между панелью Reseller и расширением.
 *
 * Работает на страницах самой панели — не на FunPay. Позволяет панели узнать,
 * что расширение стоит, показать его состояние и настройки и попросить
 * синхронизироваться. Получается «Chrome внутри сайта» в том единственном
 * виде, в каком это вообще бывает: сам браузер в страницу не встроить, а вот
 * управлять расширением из страницы — можно.
 *
 * Разговор идёт через window.postMessage, а не через идентификатор
 * расширения: у распакованного расширения идентификатор зависит от пути к
 * папке и у каждого свой, и панель его знать не может.
 *
 * Отвечаем только своей же странице (event.source === window) и только на
 * сообщения с нашей меткой. Чужие сообщения игнорируются молча.
 */
(function () {
  "use strict";

  var ВЕРСИЯ = chrome.runtime.getManifest().version;

  /** Метка в разметке: панель видит расширение ещё до всякого обмена. */
  document.documentElement.setAttribute("data-rs-ext", ВЕРСИЯ);

  function ответ(id, ok, data) {
    window.postMessage({ __rs: "res", id: id, ok: ok, data: data }, location.origin);
  }

  var КОМАНДЫ = {
    /** Состояние: когда сверялись, сколько записали, что сломалось. */
    status: function (_d, done) {
      chrome.storage.local.get(
        { состояние: null, url: "", anon: "", email: "", refresh: "", интервал: 5 },
        function (s) {
          done(true, {
            версия: ВЕРСИЯ,
            настроено: !!(s.url && s.anon),
            вошли: !!s.refresh,
            почта: s.email || "",
            адрес: s.url || "",
            интервал: s.интервал,
            состояние: s.состояние,
          });
        },
      );
    },

    /** Настройки, которые панель вправе менять. Ключи и вход — не отсюда. */
    setSettings: function (d, done) {
      var о = {};
      if (typeof d.интервал === "number" && d.интервал >= 0) о.интервал = d.интервал;
      if (!Object.keys(о).length) return done(false, "менять нечего");
      chrome.storage.local.set(о, function () {
        chrome.runtime.sendMessage({ тип: "настройкиИзменились" }, function () {
          void chrome.runtime.lastError;
        });
        done(true, о);
      });
    },

    /**
     * Попросить вкладки FunPay свериться прямо сейчас.
     *
     * `страниц` — глубина: сколько кусков истории дочитать сверх первой
     * страницы. Обычная сверка ходит без неё, глубокий проход задаёт большое
     * число и идёт минутами.
     */
    sync: function (d, done) {
      chrome.runtime.sendMessage(
        { тип: "подтолкни", страниц: Number(d && d.страниц) || 0 },
        function (r) {
          void chrome.runtime.lastError;
          done(true, r || { принято: true });
        },
      );
    },

    /**
     * Перенести настройки Supabase из панели в расширение.
     *
     * Ровно то, ради чего мост и нужен: человек уже ввёл адрес, ключ и вошёл
     * в панели — второй раз то же самое в настройках расширения вводить
     * незачем. Токены передаются внутри одного браузера и наружу не уходят.
     */
    adopt: function (d, done) {
      if (!d || !d.url || !d.anon) return done(false, "нет адреса или публичного ключа");
      if (/^sb_secret_/.test(String(d.anon))) return done(false, "это секретный ключ, нужен публичный");
      var о = { url: String(d.url).replace(/\/+$/, ""), anon: d.anon };
      if (d.email) о.email = d.email;
      if (d.token && d.refresh) {
        о.token = d.token;
        о.refresh = d.refresh;
        о.at = Number(d.at) || (Date.now() + 3600000);
      }
      chrome.storage.local.set(о, function () { done(true, { принято: true }); });
    },
  };

  window.addEventListener("message", function (e) {
    if (e.source !== window) return;                      // только своя страница
    var m = e.data;
    if (!m || m.__rs !== "req" || !m.cmd) return;
    var fn = КОМАНДЫ[m.cmd];
    if (!fn) return ответ(m.id, false, "неизвестная команда: " + m.cmd);
    try {
      fn(m.data || {}, function (ok, data) { ответ(m.id, ok, data); });
    } catch (err) {
      ответ(m.id, false, String((err && err.message) || err));
    }
  });

  // Объявляемся сами: панель может быть уже отрисована к этому моменту.
  window.postMessage({ __rs: "hello", версия: ВЕРСИЯ }, location.origin);
})();
