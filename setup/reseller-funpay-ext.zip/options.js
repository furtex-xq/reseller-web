/**
 * Настройки расширения: проект Supabase, вход и расписание.
 *
 * Вход тот же, что в панели: публичный ключ плюс почта с паролем. Пароль
 * никуда не сохраняется — остаются только выданные токены.
 */
(function () {
  "use strict";

  var $ = function (id) { return document.getElementById(id); };

  function сказать(текст, вид) {
    var d = $("msg");
    d.innerHTML = '<div class="note ' + (вид || "") + '">' + текст + "</div>";
  }

  function взять(к) { return new Promise(function (r) { chrome.storage.local.get(к, r); }); }
  function положить(о) { return new Promise(function (r) { chrome.storage.local.set(о, r); }); }

  /**
   * Адрес проекта из чего угодно: полного URL, ссылки на дашборд или просто
   * кода проекта. Код виден в адресной строке дашборда — это самый частый
   * способ его узнать.
   */
  function asUrl(text) {
    var s = String(text || "").trim();
    var direct = s.match(/https?:\/\/([a-z0-9-]+)\.supabase\.(co|in)/i);
    if (direct) return "https://" + direct[1].toLowerCase() + ".supabase." + direct[2].toLowerCase();
    var dash = s.match(/supabase\.com\/dashboard\/project\/([a-z0-9-]{16,})/i);
    if (dash) return "https://" + dash[1].toLowerCase() + ".supabase.co";
    if (/^[a-z]{16,24}$/i.test(s)) return "https://" + s.toLowerCase() + ".supabase.co";
    return "";
  }

  function sniffKey(text) {
    var pub = String(text).match(/sb_publishable_[A-Za-z0-9_-]+/);
    if (pub) return pub[0];
    var jwts = String(text).match(/eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g) || [];
    for (var i = 0; i < jwts.length; i++) {
      try {
        var role = JSON.parse(atob(jwts[i].split(".")[1].replace(/-/g, "+").replace(/_/g, "/"))).role;
        if (role === "anon") return jwts[i];
      } catch (e) { /* не тот токен */ }
    }
    return "";
  }

  function показатьВход(s) {
    var вошли = !!s.refresh;
    $("authIn").style.display = вошли ? "none" : "";
    $("authOut").style.display = вошли ? "" : "none";
    if (вошли) $("who").textContent = s.email || "—";
  }

  /* ---------------- загрузка ---------------- */
  взять({ url: "", anon: "", интервал: 5, email: "", refresh: "" }).then(function (s) {
    $("url").value = s.url || "";
    $("anon").value = s.anon || "";
    $("email").value = s.email || "";
    $("interval").value = String(s.интервал);
    показатьВход(s);
  });

  /* ---------------- разбор из буфера ---------------- */
  $("paste").onclick = function () {
    navigator.clipboard.readText().then(function (t) {
      var u = asUrl(t), k = sniffKey(t);
      if (u) $("url").value = u;
      if (k) $("anon").value = k;
      if (!u && !k) return сказать("В буфере ни адреса, ни ключа не нашлось.", "err");
      сказать("Нашлось: " + [u ? "адрес" : null, k ? "публичный ключ" : null]
        .filter(Boolean).join(" и ") + ". Проверьте и сохраните.", "ok");
    }, function () {
      сказать("Не удалось прочитать буфер — вставьте вручную.", "warn");
    });
  };

  /* ---------------- сохранение ---------------- */
  $("save").onclick = function () {
    var url = asUrl($("url").value) || String($("url").value).trim().replace(/\/+$/, "");
    var anon = String($("anon").value).trim();
    if (!url) return сказать("Адрес проекта не похож на адрес Supabase.", "err");
    if (/^sb_secret_/.test(anon)) {
      return сказать("Это секретный ключ. Нужен публичный, <code>sb_publishable_…</code>.", "err");
    }
    if (!anon) return сказать("Нужен публичный ключ.", "err");
    var м = Number($("interval").value);
    положить({ url: url, anon: anon, интервал: м }).then(function () {
      $("url").value = url;
      chrome.runtime.sendMessage({ тип: "настройкиИзменились" }, function () {
        void chrome.runtime.lastError;
      });
      сказать("Сохранено.", "ok");
    });
  };

  /* ---------------- вход ---------------- */
  $("signin").onclick = function () {
    var url = asUrl($("url").value), anon = String($("anon").value).trim();
    var email = String($("email").value).trim(), pass = $("pass").value;
    if (!url || !anon) return сказать("Сначала адрес проекта и публичный ключ.", "err");
    if (!email || !pass) return сказать("Нужны почта и пароль.", "err");

    $("signin").disabled = true;
    сказать("Вхожу…");
    fetch(url + "/auth/v1/token?grant_type=password", {
      method: "POST",
      headers: { apikey: anon, "Content-Type": "application/json" },
      body: JSON.stringify({ email: email, password: pass }),
    }).then(function (r) {
      return r.json().then(function (j) {
        if (!r.ok) {
          var m = j.error_description || j.msg || j.message || ("HTTP " + r.status);
          throw new Error(/Invalid login/i.test(m) ? "не та почта или пароль" : m);
        }
        return положить({
          url: url, anon: anon, email: email,
          token: j.access_token || "",
          refresh: j.refresh_token || "",
          at: Date.now() + (Number(j.expires_in) || 3600) * 1000,
        });
      });
    }).then(function () {
      $("pass").value = "";
      return взять({ email: "", refresh: "" });
    }).then(function (s) {
      показатьВход(s);
      сказать("Вход выполнен. Откройте вкладку FunPay — заказы поедут сами.", "ok");
    }).catch(function (e) {
      сказать("Войти не вышло: " + e.message, "err");
    }).then(function () {
      $("signin").disabled = false;
    });
  };

  $("signout").onclick = function () {
    положить({ token: "", refresh: "", at: 0 }).then(function () {
      показатьВход({ refresh: "" });
      сказать("Вы вышли.", "ok");
    });
  };

  /* ---------------- проверки ---------------- */
  $("test").onclick = function () {
    взять({ url: "", anon: "", token: "" }).then(function (s) {
      if (!s.url || !s.anon) return сказать("Сначала адрес и ключ.", "err");
      сказать("Проверяю…");
      return fetch(s.url + "/rest/v1/orders?select=id&limit=1", {
        headers: { apikey: s.anon, Authorization: "Bearer " + (s.token || s.anon) },
      }).then(function (r) {
        if (r.status === 404) return сказать("Связь есть, но таблиц нет — выполните SQL из мастера.", "warn");
        if (r.status === 401) return сказать("Связь есть, но доступа нет — войдите выше.", "warn");
        if (!r.ok) return сказать("Supabase ответил " + r.status + ".", "err");
        return r.json().then(function (rows) {
          сказать("Связь есть, таблица orders читается" +
            (rows.length ? " и в ней уже что-то лежит." : ", пока пустая."), "ok");
        });
      });
    }).catch(function (e) { сказать("Не вышло: " + e.message, "err"); });
  };

  $("now").onclick = function () {
    chrome.tabs.query({ url: "https://funpay.com/*" }, function (tabs) {
      if (!tabs.length) {
        return сказать("Нет открытых вкладок FunPay. Откройте funpay.com — и расширение " +
          "синхронизирует само.", "warn");
      }
      tabs.forEach(function (t) {
        chrome.tabs.sendMessage(t.id, { тип: "синхронизируй", повод: "из настроек" }, function () {
          void chrome.runtime.lastError;
        });
      });
      сказать("Попросил вкладку синхронизироваться. Загляните в значок расширения.", "ok");
    });
  };
})();
