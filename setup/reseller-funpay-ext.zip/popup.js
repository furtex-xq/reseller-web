/**
 * Окошко у значка: когда была сверка, сколько уехало и что пошло не так.
 *
 * Показывает не «включено», а время последней удачной сверки — иначе тишину
 * не отличить от сломанной синхронизации.
 */
(function () {
  "use strict";

  var $ = function (id) { return document.getElementById(id); };

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c];
    });
  }

  function давно(iso) {
    if (!iso) return "";
    var сек = Math.round((Date.now() - new Date(iso).getTime()) / 1000);
    if (сек < 60) return "только что";
    if (сек < 3600) return Math.round(сек / 60) + " мин назад";
    if (сек < 86400) return Math.round(сек / 3600) + " ч назад";
    return new Date(iso).toLocaleDateString("ru-RU");
  }

  function строки(о) {
    var q = о.качество || {};
    if (!q.всего) return "";
    var t = "<table>";
    t += "<tr><td>нашлось заказов</td><td class='v'>" + esc(q.всего) + "</td></tr>";
    t += "<tr><td>записано</td><td class='v'>" + esc(о.записано) + "</td></tr>";
    if (q.всего !== q.сПокупателем) {
      t += "<tr><td>без покупателя</td><td class='v'>" + esc(q.всего - q.сПокупателем) + "</td></tr>";
    }
    if (q.всего !== q.сДатой) {
      t += "<tr><td>без даты</td><td class='v'>" + esc(q.всего - q.сДатой) + "</td></tr>";
    }
    return t + "</table>";
  }

  chrome.storage.local.get({ состояние: null, url: "", refresh: "" }, function (s) {
    var d = $("state");

    if (!s.url) {
      d.className = "state warn";
      d.innerHTML = "Проект Supabase не настроен.<br>Откройте настройки.";
      return;
    }
    if (!s.refresh) {
      d.className = "state warn";
      d.innerHTML = "Вход в Supabase не выполнен.<br>Почта и пароль — в настройках.";
      return;
    }
    var о = s.состояние;
    if (!о) {
      d.className = "state mute";
      d.innerHTML = "Сверок ещё не было.<br>Откройте вкладку funpay.com.";
      return;
    }
    if (!о.ok) {
      d.className = "state err";
      d.innerHTML = "<b>Не вышло.</b><br>" + esc(о.причина || "неизвестно") +
        "<div class='when'>" + давно(о.когда) + "</div>" +
        (о.сырые ? "<pre>" + esc(JSON.stringify(о.сырые, null, 1)) + "</pre>" : "");
      return;
    }
    var q = о.качество || {};
    var плохо = (q.всего || 0) - Math.min(q.сПокупателем || 0, q.сДатой || 0);
    d.className = "state " + (плохо ? "warn" : "ok");
    d.innerHTML = "<b>" + (плохо ? "Работает, но не всё разобралось" : "Работает") + "</b>" +
      строки(о) +
      "<div class='when'>сверка " + давно(о.когда) + "</div>" +
      (плохо && о.сырые ? "<pre>" + esc(JSON.stringify(о.сырые, null, 1)) + "</pre>" : "");
  });

  $("now").onclick = function () {
    chrome.tabs.query({ url: "https://funpay.com/*" }, function (tabs) {
      var d = $("state");
      if (!tabs.length) {
        d.className = "state warn";
        d.innerHTML = "Нет открытых вкладок FunPay.<br>Откройте funpay.com.";
        return;
      }
      tabs.forEach(function (t) {
        chrome.tabs.sendMessage(t.id, { тип: "синхронизируй", повод: "из окошка" }, function () {
          void chrome.runtime.lastError;
        });
      });
      d.className = "state mute";
      d.innerHTML = "Попросил вкладку сверить…<br>Закройте и откройте окошко через пару секунд.";
    });
  };

  $("opts").onclick = function () { chrome.runtime.openOptionsPage(); };
})();
